package vn.rapphuongnam.entity;

//QuyTacGia.khungGio, chia theo gio bat dau suat chieu giong view vw_SuatChieuGia
public enum KhungGio {
    sang("Sáng", "trước 11:00"),
    trua("Trưa", "11:00 – 13:59"),
    chieu("Chiều", "14:00 – 17:59"),
    toi("Tối", "từ 18:00");

    private final String nhan;
    private final String moTa;

    KhungGio(String nhan, String moTa) {
        this.nhan = nhan;
        this.moTa = moTa;
    }

    public String getNhan() { return nhan; }
    public String getMoTa() { return moTa; }
}
